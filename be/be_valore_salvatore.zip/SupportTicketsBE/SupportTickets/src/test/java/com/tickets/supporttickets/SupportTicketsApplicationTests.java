package com.tickets.supporttickets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupportTicketsApplicationTests {

	@Test
	void contextLoads() {
	}

}
