package com.tickets.supporttickets.services;

import com.tickets.supporttickets.models.Ticket;

import java.sql.Blob;
import java.util.List;

public interface TicketService {
    String addTicket(Ticket ticket);
    List<Ticket> getAllTickets();
    List<Ticket> getTicketsByCustomerEmail(String email);
    Ticket getTicketById(Long id);
    void updateTicket(Ticket ticket);
    String deleteTicket(Long id);
    String uploadDocumentation(Blob documentation);
}
