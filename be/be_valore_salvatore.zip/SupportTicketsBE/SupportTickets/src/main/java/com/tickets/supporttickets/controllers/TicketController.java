package com.tickets.supporttickets.controllers;

import com.tickets.supporttickets.models.Ticket;
import com.tickets.supporttickets.services.DBs.TicketServiceDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class TicketController {
    @Autowired
    private TicketServiceDB ticketServiceDB;

    @PostMapping(value = "/tickets/add")
    public String addTicket(@RequestBody Ticket ticket){
        return this.ticketServiceDB.addTicket(ticket);
    }

    @GetMapping(value = "/tickets/getAll")
    public List<Ticket> getAllTickets(){
        return this.ticketServiceDB.getAllTickets();
    }

    @GetMapping(value = "/tickets/getByCustomerEmail")
    public List<Ticket> getTicketsByCustomerEmail(@RequestParam String email){
        return this.ticketServiceDB.getTicketsByCustomerEmail(email);
    }

    @GetMapping(value = "/tickets/getById")
    public Ticket getTicketById(@RequestParam Long id){
        return this.ticketServiceDB.getTicketById(id);
    }

    @PostMapping(value = "/tickets/update")
    public void updateTicket(@RequestBody Ticket ticket){
        this.ticketServiceDB.updateTicket(ticket);
    }

    @DeleteMapping(value = "/tickets/delete")
    public String deleteTicket(@RequestParam Long id){
        return this.ticketServiceDB.deleteTicket(id);
    }
}
