package com.tickets.supporttickets.services.DBs;

import com.tickets.supporttickets.models.Operator;
import com.tickets.supporttickets.models.Ticket;
import com.tickets.supporttickets.repositories.OperatorRepository;
import com.tickets.supporttickets.repositories.TicketRepository;
import com.tickets.supporttickets.services.TicketService;
import com.tickets.supporttickets.services.utilities.EmailSenderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Blob;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class TicketServiceDB implements TicketService {
    @Autowired
    private TicketRepository ticketRepository;

    @Autowired
    private OperatorRepository operatorRepository;

    @Autowired
    private EmailSenderService emailSenderService;

    @Override
    public String addTicket(Ticket ticket) {
        if(this.ticketRepository.findById(ticket.getId()).isEmpty()){
            this.ticketRepository.save(ticket);
            for (Operator operator : this.operatorRepository.findAll()){
                this.emailSenderService.sendEmail(operator.getEmail(), "Nuovo Ticket", ticket.getCustomer().getEmail() + " ha creato un nuovo ticket\n\n" + "Oggetto:\n" + ticket.getObject() + "\n\nDescrizione:\n" + ticket.getDescription());
            }
            return "Operation Success!";
        }
        return "Error! There is already a Ticket with this ID!";
    }

    @Override
    public List<Ticket> getAllTickets() {
        return this.ticketRepository.findAll();
    }

    @Override
    public List<Ticket> getTicketsByCustomerEmail(String email) {
        return this.ticketRepository.findByCustomerEmail(email);
    }

    @Override
    public Ticket getTicketById(Long id) {
        return this.ticketRepository.findById(id).orElse(null);
    }

    @Override
    public void updateTicket(Ticket ticket) {
        Optional<Ticket> optionalTicket = this.ticketRepository.findById(ticket.getId());
        if(optionalTicket.isPresent()){
            if(ticket.getVersion() == optionalTicket.get().getVersion() + 1){
                if(!Objects.equals(ticket.getState(), this.ticketRepository.findById(ticket.getId()).get().getState())){
                    this.emailSenderService.sendEmail(ticket.getCustomer().getEmail(), "Aggiornamento Stato Ticket", "Lo stato del tuo ticket con Oggetto: " + ticket.getObject() + " è ");
                }
                this.ticketRepository.save(ticket);
            }
        }
    }

    @Override
    public String deleteTicket(Long id) {
        if(this.ticketRepository.findById(id).isPresent()){
            this.ticketRepository.deleteById(id);
            return "Operation Success!";
        }
        return "Error! There isn't a Ticket with this ID!";
    }

    @Override
    public String uploadDocumentation(Blob documentation) {
        return null;
    }
}
