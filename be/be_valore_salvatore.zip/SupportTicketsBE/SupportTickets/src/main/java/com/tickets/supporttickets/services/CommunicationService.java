package com.tickets.supporttickets.services;

import com.tickets.supporttickets.models.Communication;

import java.util.List;

public interface CommunicationService {
    String addCommunication(Communication communication);
    List<Communication> getAllCommunications();
    String updateCommunication(Communication communication);
    String deleteCommunication(Long id);
}
