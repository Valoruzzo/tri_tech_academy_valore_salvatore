package com.tickets.supporttickets.services;

import com.tickets.supporttickets.models.Customer;

import java.util.List;

public interface CustomerService {
    void addCustomer(Customer customer);
    List<Customer> getAllCustomers();
    String updateCustomer(Customer customer);
    String deleteCustomer(Long id);
    Customer getCustomerByEmail(String email);
}
