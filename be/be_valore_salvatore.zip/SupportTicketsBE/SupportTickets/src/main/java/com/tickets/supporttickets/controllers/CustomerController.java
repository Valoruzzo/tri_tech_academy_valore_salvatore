package com.tickets.supporttickets.controllers;

import com.tickets.supporttickets.models.Customer;
import com.tickets.supporttickets.services.DBs.CustomerServiceDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CustomerController {
    @Autowired
    private CustomerServiceDB customerServiceDB;

    @PostMapping(value = "/customers/add")
    public void addCustomer(@RequestBody Customer customer){
        this.customerServiceDB.addCustomer(customer);
    }

    @GetMapping(value = "/customers/getAll")
    public List<Customer> getAllCustomers(){
        return this.customerServiceDB.getAllCustomers();
    }

    @PostMapping(value = "/customers/update")
    public String updateCustomer(@RequestBody Customer customer){
        return this.customerServiceDB.updateCustomer(customer);
    }

    @DeleteMapping(value = "/customers/delete")
    public String deleteCustomer(@RequestParam Long id){
        return this.customerServiceDB.deleteCustomer(id);
    }

    @GetMapping(value = "/customers/getByEmail")
    public Customer getCustomerByEmail(@RequestParam String email){
        return this.customerServiceDB.getCustomerByEmail(email);
    }
}
