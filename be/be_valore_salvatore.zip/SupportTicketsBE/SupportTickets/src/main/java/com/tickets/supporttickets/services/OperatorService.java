package com.tickets.supporttickets.services;

import com.tickets.supporttickets.models.Customer;
import com.tickets.supporttickets.models.Operator;

import java.util.List;

public interface OperatorService {
    void addOperator(Operator operator);
    List<Operator> getAllOperators();
    void updateOperator(Operator operator);
    void deleteOperator(Long id);
    Operator getOperatorByEmail(String email);
}
