package com.tickets.supporttickets.controllers;

import com.tickets.supporttickets.models.Communication;
import com.tickets.supporttickets.services.DBs.CommunicationServiceDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CommunicationController {
    @Autowired
    private CommunicationServiceDB communicationServiceDB;

    @PostMapping(value = "/communications/add")
    public String addCommunication(@RequestBody Communication communication){
        return this.communicationServiceDB.addCommunication(communication);
    }

    @GetMapping(value = "/communications/getAll")
    public List<Communication> getAllCommunications(){
        return this.communicationServiceDB.getAllCommunications();
    }

    @PostMapping(value = "/communications/update")
    public String updateCommunication(@RequestBody Communication communication){
        return this.communicationServiceDB.updateCommunication(communication);
    }

    @DeleteMapping(value = "/communications/delete")
    public String deleteCommunication(@RequestParam Long id){
        return this.communicationServiceDB.deleteCommunication(id);
    }
}
