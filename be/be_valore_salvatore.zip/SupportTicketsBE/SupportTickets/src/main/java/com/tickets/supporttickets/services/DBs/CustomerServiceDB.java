package com.tickets.supporttickets.services.DBs;

import com.tickets.supporttickets.models.Customer;
import com.tickets.supporttickets.repositories.CustomerRepository;
import com.tickets.supporttickets.services.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceDB implements CustomerService {
    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public void addCustomer(Customer customer) {
        if(this.customerRepository.findById(customer.getId()).isEmpty()){
            if(this.customerRepository.findByEmail(customer.getEmail()).isEmpty()){
                this.customerRepository.save(customer);
            }
        }
    }

    @Override
    public List<Customer> getAllCustomers() {
        return this.customerRepository.findAll();
    }

    @Override
    public String updateCustomer(Customer customer) {
        if(this.customerRepository.findById(customer.getId()).isPresent()){
            this.customerRepository.save(customer);
            return "Operation Success!";
        }
        return "Error! There isn't a Customer with this ID!";
    }

    @Override
    public String deleteCustomer(Long id) {
        if(this.customerRepository.findById(id).isPresent()){
            this.customerRepository.deleteById(id);
            return "Operation Success!";
        }
        return "Error! There isn't a Customer with this ID!";
    }

    @Override
    public Customer getCustomerByEmail(String email) {
        return this.customerRepository.findByEmail(email).orElse(null);
    }
}
