package com.tickets.supporttickets.services.DBs;

import com.tickets.supporttickets.models.Communication;
import com.tickets.supporttickets.repositories.CommunicationRepository;
import com.tickets.supporttickets.services.CommunicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommunicationServiceDB implements CommunicationService {
    @Autowired
    private CommunicationRepository communicationRepository;

    @Override
    public String addCommunication(Communication communication) {
        if(this.communicationRepository.findById(communication.getId()).isEmpty()){
            this.communicationRepository.save(communication);
            return "Operation Success!";
        }
        return "Error! There is already a Communication with this ID!";
    }

    @Override
    public List<Communication> getAllCommunications() {
        return this.communicationRepository.findAll();
    }

    @Override
    public String updateCommunication(Communication communication) {
        if(this.communicationRepository.findById(communication.getId()).isPresent()){
            this.communicationRepository.save(communication);
            return "Operation Success!";
        }
        return "Error! There isn't a Communication with this ID!";
    }

    @Override
    public String deleteCommunication(Long id) {
        if(this.communicationRepository.findById(id).isPresent()){
            this.communicationRepository.deleteById(id);
            return "Operation Success!";
        }
        return "Error! There isn't a Communication with this ID!";
    }
}
