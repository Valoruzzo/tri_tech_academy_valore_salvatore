package com.tickets.supporttickets.services.DBs;

import com.tickets.supporttickets.models.Assignment;
import com.tickets.supporttickets.repositories.AssignmentRepository;
import com.tickets.supporttickets.services.AssignmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AssignmentServiceDB implements AssignmentService {
    @Autowired
    private AssignmentRepository assignmentRepository;

    @Override
    public String addAssignment(Assignment assignment) {
        if(this.assignmentRepository.findById(assignment.getId()).isEmpty()){
            this.assignmentRepository.save(assignment);
            return "Operation Success!";
        }
        return "Error! There is already an Assignment with this ID!";
    }

    @Override
    public List<Assignment> getAllAssignments() {
        return this.assignmentRepository.findAll();
    }

    @Override
    public String updateAssignment(Assignment assignment) {
        if(this.assignmentRepository.findById(assignment.getId()).isPresent()){
            this.assignmentRepository.save(assignment);
            return "Operation Success!";
        }
        return "Error! There isn't an Assignment with this ID!";
    }

    @Override
    public String deleteAssignment(Long id) {
        if(this.assignmentRepository.findById(id).isPresent()){
            this.assignmentRepository.deleteById(id);
            return "Operation Success!";
        }
        return "Error! There isn't a Assignment with this ID!";
    }
}
