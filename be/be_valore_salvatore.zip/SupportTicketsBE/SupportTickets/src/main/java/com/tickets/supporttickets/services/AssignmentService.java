package com.tickets.supporttickets.services;

import com.tickets.supporttickets.models.Assignment;

import java.util.List;

public interface AssignmentService {
    String addAssignment(Assignment assignment);
    List<Assignment> getAllAssignments();
    String updateAssignment(Assignment assignment);
    String deleteAssignment(Long id);
}
