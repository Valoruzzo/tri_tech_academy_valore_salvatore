package com.tickets.supporttickets.models;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "sv_communication")
public class Communication {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String object;
    private String body;
    private LocalDateTime sendDate;
    @ManyToOne
    @JoinColumn(name = "ticket", referencedColumnName = "id")
    private Ticket ticket;
    @ManyToOne
    @JoinColumn(name = "customer", referencedColumnName = "id")
    private Customer customer;
    @ManyToOne
    @JoinColumn(name = "operator", referencedColumnName = "id")
    private Operator operator;
}
