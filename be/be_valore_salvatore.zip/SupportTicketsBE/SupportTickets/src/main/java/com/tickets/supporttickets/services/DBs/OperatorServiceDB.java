package com.tickets.supporttickets.services.DBs;

import com.tickets.supporttickets.models.Operator;
import com.tickets.supporttickets.repositories.OperatorRepository;
import com.tickets.supporttickets.services.OperatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OperatorServiceDB implements OperatorService {
    @Autowired
    private OperatorRepository operatorRepository;

    @Override
    public void addOperator(Operator operator) {
        if(this.operatorRepository.findById(operator.getId()).isEmpty()){
            if(this.operatorRepository.findByEmail(operator.getEmail()).isEmpty()){
                this.operatorRepository.save(operator);
            }
        }
    }

    @Override
    public List<Operator> getAllOperators() {
        return this.operatorRepository.findAll();
    }

    @Override
    public void updateOperator(Operator operator) {
        if(this.operatorRepository.findById(operator.getId()).isPresent()){
            this.operatorRepository.save(operator);
        }
    }

    @Override
    public void deleteOperator(Long id) {
        if(this.operatorRepository.findById(id).isPresent()){
            this.operatorRepository.deleteById(id);
        }
    }

    @Override
    public Operator getOperatorByEmail(String email) {
        return this.operatorRepository.findByEmail(email).orElse(null);
    }
}
