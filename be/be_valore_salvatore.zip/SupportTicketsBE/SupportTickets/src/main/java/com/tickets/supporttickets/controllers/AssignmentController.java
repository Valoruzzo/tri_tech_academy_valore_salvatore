package com.tickets.supporttickets.controllers;

import com.tickets.supporttickets.models.Assignment;
import com.tickets.supporttickets.services.DBs.AssignmentServiceDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class AssignmentController {
    @Autowired
    private AssignmentServiceDB assignmentServiceDB;

    @PostMapping(value = "/assignments/add")
    public String addAssignment(@RequestBody Assignment assignment){
        return this.assignmentServiceDB.addAssignment(assignment);
    }

    @GetMapping(value = "/assignments/getAll")
    public List<Assignment> getAllAssignments(){
        return this.assignmentServiceDB.getAllAssignments();
    }

    @PostMapping(value = "/assignments/update")
    public String updateAssignment(@RequestBody Assignment assignment){
        return this.assignmentServiceDB.updateAssignment(assignment);
    }

    @DeleteMapping(value = "/assignments/delete")
    public String deleteAssignment(@RequestParam Long id){
        return this.assignmentServiceDB.deleteAssignment(id);
    }
}
