package com.tickets.supporttickets.controllers;

import com.tickets.supporttickets.models.Customer;
import com.tickets.supporttickets.models.Operator;
import com.tickets.supporttickets.services.DBs.OperatorServiceDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class OperatorController {
    @Autowired
    private OperatorServiceDB operatorServiceDB;

    @PostMapping(value = "/operators/add")
    public void addOperator(@RequestBody Operator operator){
        this.operatorServiceDB.addOperator(operator);
    }

    @GetMapping(value = "/operators/getAll")
    public List<Operator> getAllOperators(){
        return this.operatorServiceDB.getAllOperators();
    }

    @PostMapping(value = "/operators/update")
    public void updateOperator(@RequestBody Operator operator){
        this.operatorServiceDB.updateOperator(operator);
    }

    @DeleteMapping(value = "/operators/delete")
    public void deleteOperator(@RequestParam Long id){
        this.operatorServiceDB.deleteOperator(id);
    }

    @GetMapping(value = "/operators/getByEmail")
    public Operator getOperatorByEmail(@RequestParam String email){
        return this.operatorServiceDB.getOperatorByEmail(email);
    }
}
