export interface Customer{
    id: number,
    firstName: string,
    lastName: string,
    email: string,
    password: string,
    birthDate: Date,
    phoneNumber: string,
    address: string
}

export interface Ticket{
    id: number,
    object: string,
    description: string,
    furtherInformations: string,
    documentation: any,
    creationDate: Date,
    state: string,
    priority: string,
    version: number,
    customer: Customer
}

export interface Operator{
    id: number,
    firstName: string,
    lastName: string,
    email: string,
    password: string,
    birthDate: Date,
    phoneNumber: string,
    address: string,
    authorizationLevel: string
}

export interface Assignment{
    id: number,
    operationDate: Date,
    ticket: Ticket,
    operator: Operator
}

export interface Communication{
    id: number,
    object: string,
    body: string,
    sendDate: Date,
    ticket: Ticket,
    customer: Customer,
    operator: Operator
}