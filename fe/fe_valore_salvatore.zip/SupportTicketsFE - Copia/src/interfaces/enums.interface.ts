export enum States{
    Open="OPEN",
    UnderProcessing="UNDER PROCESSING",
    Canceled="CANCELED",
    Suspended="SUSPENDED",
    Resolved="RESOLVED",
    Closed="CLOSED"
}

export enum Priorities{
    Normal="NORMAL",
    Important="IMPORTANT",
    VeryImportant="VERY IMPORTANT",
    Urgent="URGENT"
}