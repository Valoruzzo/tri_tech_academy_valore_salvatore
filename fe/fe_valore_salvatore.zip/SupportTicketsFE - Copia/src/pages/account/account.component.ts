import { Component } from '@angular/core';
import { NavBarTopComponent } from "../../components/navbartop/navbartop.component";
import { LogInFormComponent } from "../../components/loginform/loginform.component";
import { AccountService } from '../../services/account.service';
import { CommonModule } from '@angular/common';
import { SignInFormComponent } from "../../components/signinform/signinform.component";
import { LoadingService } from '../../services/loading.service';
import { LoadingComponent } from "../../components/loading/loading.component";

@Component({
    selector: 'account',
    standalone: true,
    templateUrl: './account.component.html',
    styleUrl: './account.component.css',
    imports: [NavBarTopComponent, LogInFormComponent, CommonModule, SignInFormComponent, LoadingComponent]
})
export class AccountComponent {

    constructor(private accSrv: AccountService, private ldgSrv: LoadingService) { }
  
    get getAcc() {
      return this.accSrv;
    }
  
    get getLdg() {
      return this.ldgSrv;
    }

    logOut() {
      this.accSrv.accountIsLogged = false;
    }
}
