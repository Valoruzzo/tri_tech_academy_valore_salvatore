import { Component } from '@angular/core';
import { NavBarTopComponent } from '../../components/navbartop/navbartop.component';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AccountService } from '../../services/account.service';

@Component({
    selector: 'home',
    standalone: true,
    templateUrl: './home.component.html',
    styleUrl: './home.component.css',
    imports: [NavBarTopComponent, CommonModule]
})
export class HomeComponent {

  constructor(private accSrv: AccountService, private router: Router) { }

  get getAcc() {
    return this.accSrv;
  }

  navigateToPage(page: string): void{
    this.router.navigate(["/" + page]);
  }

  logIn(): void{
    this.accSrv.logIn();
    this.navigateToPage('account');
  }

  signIn(): void{
    this.accSrv.signIn();
    this.navigateToPage('account');
  }
}