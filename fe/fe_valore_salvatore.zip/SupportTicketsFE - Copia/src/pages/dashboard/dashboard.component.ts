import { Component, OnInit } from '@angular/core';
import { NavBarTopComponent } from "../../components/navbartop/navbartop.component";
import { HttpClient } from '@angular/common/http';
import { Ticket } from '../../interfaces/artificialtypes.interface';
import { CommonModule } from '@angular/common';
import { Strings } from '../../interfaces/strings.interface';
import { TicketService } from '../../services/ticket.service';
import { TicketComponent } from "../../components/ticket/ticket.component";
import { LoadingComponent } from "../../components/loading/loading.component";
import { LoadingService } from '../../services/loading.service';

@Component({
    selector: 'dashboard',
    standalone: true,
    templateUrl: './dashboard.component.html',
    styleUrl: './dashboard.component.css',
    imports: [NavBarTopComponent, CommonModule, TicketComponent, LoadingComponent]
})
export class DashboardComponent implements OnInit {

    constructor(private http: HttpClient, private tktSrv: TicketService, private ldgSrv: LoadingService) { }

    allTickets: Ticket[] = [];

    get getStrings() {
        return Strings;
    }

    get getTkt() {
        return this.tktSrv;
    }

    get getLdg() {
        return this.ldgSrv;
    }

    ngOnInit(): void {
        this.ldgSrv.loading = true;
        this.http.get<Ticket[]>('http://localhost:8080/tickets/getAll')
        .subscribe(tickets => {
            this.allTickets = tickets;
            this.ldgSrv.loading = false;
        });
    }

    goToTicket(id: number): void {
        this.tktSrv.getTicket(id);
        this.tktSrv.singleTicket = true;
    }
}
