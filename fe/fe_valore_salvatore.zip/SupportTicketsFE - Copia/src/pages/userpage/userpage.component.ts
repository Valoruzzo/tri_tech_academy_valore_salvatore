import { Component, OnInit } from '@angular/core';
import { NavBarTopComponent } from "../../components/navbartop/navbartop.component";
import { SupportTicketsFormComponent } from "../../components/supportticketsform/supportticketsform.component";
import { AccountService } from '../../services/account.service';
import { CommonModule } from '@angular/common';
import { LoadingService } from '../../services/loading.service';
import { TicketService } from '../../services/ticket.service';
import { HttpClient } from '@angular/common/http';
import { Ticket } from '../../interfaces/artificialtypes.interface';
import { Strings } from '../../interfaces/strings.interface';
import { LoadingComponent } from "../../components/loading/loading.component";
import { TicketComponent } from "../../components/ticket/ticket.component";

@Component({
    selector: 'userpage',
    standalone: true,
    templateUrl: './userpage.component.html',
    styleUrl: './userpage.component.css',
    imports: [NavBarTopComponent, SupportTicketsFormComponent, CommonModule, LoadingComponent, TicketComponent]
})
export class UserPageComponent implements OnInit {

    constructor(private http: HttpClient, private tktSrv: TicketService, private ldgSrv: LoadingService, private accSrv: AccountService) { }

    tickets: Ticket[] = [];

    get getStrings() {
        return Strings;
    }

    get getAcc() {
        return this.accSrv;
    }

    get getTkt() {
        return this.tktSrv;
    }

    get getLdg() {
        return this.ldgSrv;
    }

    ngOnInit(): void {
        if(this.accSrv.accountIsLogged){
            this.tktSrv.createTicket = false;
            this.ldgSrv.loading = true;
            this.http.get<Ticket[]>('http://localhost:8080/tickets/getByCustomerEmail' + '?email=' + this.accSrv.accountEmail)
            .subscribe(tickets => {
                this.tickets = tickets;
                this.ldgSrv.loading = false;
            });
        }
    }

    goToTicket(id: number): void {
        this.tktSrv.getTicket(id);
        this.tktSrv.singleTicket = true;
    }
}
