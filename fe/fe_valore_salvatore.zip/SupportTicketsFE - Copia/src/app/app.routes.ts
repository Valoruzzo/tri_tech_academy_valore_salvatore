import { Routes } from '@angular/router';
import { HomeComponent } from '../pages/home/home.component';
import { DashboardComponent } from '../pages/dashboard/dashboard.component';
import { UserPageComponent } from '../pages/userpage/userpage.component';
import { AccountComponent } from '../pages/account/account.component';

export const routes: Routes = [
    {path: '', component: HomeComponent},
    {path: 'dashboard', component: DashboardComponent},
    {path: 'userpage', component: UserPageComponent},
    {path: 'account', component: AccountComponent}
];
