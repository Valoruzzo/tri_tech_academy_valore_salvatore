import { AfterViewInit, Component, ElementRef, OnInit, ViewChild, input } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Customer, Ticket } from '../../interfaces/artificialtypes.interface';
import { HttpClient } from '@angular/common/http';
import { Strings } from '../../interfaces/strings.interface';
import { AccountService } from '../../services/account.service';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { TicketService } from '../../services/ticket.service';
import { States, Priorities } from '../../interfaces/enums.interface'

@Component({
  selector: 'supportticketsform',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './supportticketsform.component.html',
  styleUrl: './supportticketsform.component.css'
})
export class SupportTicketsFormComponent implements OnInit, AfterViewInit {

  @ViewChild('upload') upload!: ElementRef;

  files!: any;

  constructor(private fb: FormBuilder, private http: HttpClient, private accSrv: AccountService, private tktSrv: TicketService, private router: Router) { }

  ticketForm!: FormGroup;

  emailFoundError: boolean = false;
  email: string = '';
  emailNotFoundError: boolean = false;
  operatorEmailError: boolean = false;

  get getAcc() {
    return this.accSrv;
  }

  get getStrings() {
    return Strings;
  }

  get getTkt() {
    return this.tktSrv;
  }

  ngOnInit(): void {
    this.ticketForm = this.fb.group({
      firstName: ['', [Validators.minLength(3)]],
      lastName: ['', [Validators.minLength(3)]],
      email: [this.accSrv.accountEmail, [Validators.required, Validators.email]],
      birthDate: [''],
      phoneNumber: ['', [Validators.min(100000)]],
      address: [''],
      object: [this.tktSrv.ticketFields[0], [Validators.required]],
      furtherInformations: [this.tktSrv.ticketFields[1]],
      description: [this.tktSrv.ticketFields[2], [Validators.required]],
      documentation: [this.tktSrv.ticketFields[3]]
    });
  }

  ngAfterViewInit(): void {
    this.upload.nativeElement.files = this.tktSrv.ticketFields[4];
  }

  submit(): void{
    let email = this.ticketForm.value.email;
    if(!this.getAcc.accountIsLogged){
      this.tktSrv.ticketFields = [];
      this.tktSrv.ticketFields.push(this.ticketForm.value.object);
      this.tktSrv.ticketFields.push(this.ticketForm.value.furtherInformations);
      this.tktSrv.ticketFields.push(this.ticketForm.value.description);
      this.tktSrv.ticketFields.push(this.ticketForm.value.documentation);
      this.tktSrv.ticketFields.push(this.files);
      this.accSrv.checkOperatorEmail(email)
      .subscribe(operator => {
        if(operator == null){
          this.accSrv.checkCustomerEmail(email)
          .subscribe(customer  => {
            if(customer == null){
              this.operatorEmailError = false;
              this.emailFoundError = false;
              this.emailNotFoundError = true;
              this.email = email;
            } else {
              this.operatorEmailError = false;
              this.emailFoundError = true;
              this.emailNotFoundError = false;
              this.email = email;
            }
          });
        } else {
          this.operatorEmailError = true;
          this.emailFoundError = false;
          this.emailNotFoundError = false;
        }
      });
    } else {
      this.accSrv.checkCustomerEmail(email)
      .subscribe(customer  => {
        this.setTicket(customer);
      });
    }
  }

  setTicket(customer: Customer): void{
    alert('Ticket inviato con successo');
    let ticket: Ticket;
    if(this.ticketForm.value.documentation != '' && this.ticketForm.value.documentation != undefined){
    this.base64(this.ticketForm.value.documentation)
    .then(data => {
      ticket = {
        id: 0,
        object: this.ticketForm.value.object,
        description: this.ticketForm.value.description,
        furtherInformations: this.ticketForm.value.furtherInformations,
        documentation: data,
        creationDate: new Date(),
        state: States.Open,
        priority: Priorities.Normal,
        version: 0,
        customer: customer
      }
    })
    .then(() => this.tktSrv.addTicket(ticket).subscribe());
    } else {
      ticket = {
        id: 0,
        object: this.ticketForm.value.object,
        description: this.ticketForm.value.description,
        furtherInformations: this.ticketForm.value.furtherInformations,
        documentation: this.ticketForm.value.documentation,
        creationDate: new Date(),
        state: 'OPEN',
        priority: 'NORMAL',
        version: 0,
        customer: customer
      }
      this.tktSrv.addTicket(ticket).subscribe();
    }
  }

  getFile(event: Event): void{
    let inputElement = event.target as HTMLInputElement;
    let theFile = inputElement.files?.[0];
    this.ticketForm.patchValue({documentation: theFile});
    this.files = inputElement.files;
  }

  base64(file: File): Promise<string>{
    return new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        resolve(base64String.split(',')[1]);
      }
      reader.onerror = () => {
        reject(new Error('Errore nella lettura del documento!'));
      }
      reader.readAsDataURL(file);
    });
  }

  navigateToPage(page: string): void{
    this.router.navigate(["/" + page]);
  }

  logIn(): void{
    this.accSrv.logIn();
    this.accSrv.fillAccess = [];
    this.accSrv.fillAccess.push(this.email);
    this.navigateToPage('account');
  }

  signIn(): void{
    this.accSrv.signIn();
    this.accSrv.fillRegistration = [];
    this.accSrv.fillRegistration.push(this.ticketForm.value.firstName);
    this.accSrv.fillRegistration.push(this.ticketForm.value.lastName);
    this.accSrv.fillRegistration.push(this.ticketForm.value.birthDate);
    this.accSrv.fillRegistration.push(this.ticketForm.value.phoneNumber);
    this.accSrv.fillRegistration.push(this.ticketForm.value.address);
    this.accSrv.fillRegistration.push(this.getStrings.customerTypeValue);
    this.accSrv.fillRegistration.push(this.email);
    this.navigateToPage('account');
  }
}