import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupportTicketsFormComponent } from './supportticketsform.component';

describe('SupportTicketsFormComponent', () => {
  let component: SupportTicketsFormComponent;
  let fixture: ComponentFixture<SupportTicketsFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SupportTicketsFormComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SupportTicketsFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
