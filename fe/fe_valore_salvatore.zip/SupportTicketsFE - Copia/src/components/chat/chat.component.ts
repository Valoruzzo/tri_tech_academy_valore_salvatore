import { HttpClient } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { TicketService } from '../../services/ticket.service'
import { AccountService } from '../../services/account.service'
import { Ticket } from '../../interfaces/artificialtypes.interface';
import { CommonModule, NgClass } from '@angular/common';

@Component({
  selector: 'chat',
  standalone: true,
  imports: [NgClass, CommonModule],
  templateUrl: './chat.component.html',
  styleUrl: './chat.component.css'
})
export class ChatComponent implements OnInit {

  messages!: {body: string, type: string}[];

  constructor(private http: HttpClient, private tktSrv: TicketService, private accSrv: AccountService) { }

  @ViewChild('chat') chat!: ElementRef;

  get getAcc() {
    return this.accSrv;
  }

  ngOnInit(): void {
    this.http.get<Ticket[]>('http://localhost:8080/tickets/getAll')
    .subscribe(tickets => {
      tickets.forEach(ticket => {
        
      });
    })
  }

  toggleChat() {
    if(this.chat.nativeElement.style.display == 'block'){
      this.chat.nativeElement.style.display = 'none';
    } else {
      this.chat.nativeElement.style.display = 'block';
    }
  }
}
