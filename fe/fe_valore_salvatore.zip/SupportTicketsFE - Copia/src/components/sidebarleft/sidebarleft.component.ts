import { Component } from '@angular/core';
import { SideBarLeftOpeningService } from '../../services/sidebarleftopening.service';
import { CommonModule, NgStyle } from '@angular/common';
import { Router } from '@angular/router';
import { AccountService } from '../../services/account.service';

@Component({
  selector: 'sidebarleft',
  standalone: true,
  imports: [NgStyle, CommonModule],
  templateUrl: './sidebarleft.component.html',
  styleUrl: './sidebarleft.component.css'
})
export class SideBarLeftComponent {
  constructor(private sdbOp: SideBarLeftOpeningService, private router: Router, private accSrv: AccountService) { }

  get getSdbOp() {
    return this.sdbOp;
  }

  get getAcc() {
    return this.accSrv;
  }

  navigateToPage(page: string): void{
    this.router.navigate(["/" + page]);
    this.sdbOp.toggleSideBarLeft();
  }

  changeSrc(event: MouseEvent): void{
    let element = event.target as HTMLElement | ParentNode | null;
    if(!(element instanceof HTMLDivElement)){
      element = element!.parentNode;
    }
    let imageElement = element!.firstElementChild as HTMLImageElement;
    imageElement.src = imageElement.src.replace('black', 'white');
  }

  resetSrc(event: MouseEvent): void{
    let element = event.target as HTMLElement | ParentNode | null;
    if(!(element instanceof HTMLDivElement)){
      element = element!.parentNode;
    }
    let imageElement = element!.firstElementChild as HTMLImageElement;
    imageElement.src = imageElement.src.replace('white', 'black');
  }
}
