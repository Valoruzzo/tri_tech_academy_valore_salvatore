import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { TicketService } from '../../services/ticket.service';
import { AccountService } from '../../services/account.service';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Priorities, States } from '../../interfaces/enums.interface';
import { HttpClient } from '@angular/common/http';
import { Ticket } from '../../interfaces/artificialtypes.interface';
import { ChatComponent } from "../chat/chat.component";

@Component({
    selector: 'ticket',
    standalone: true,
    templateUrl: './ticket.component.html',
    styleUrl: './ticket.component.css',
    imports: [CommonModule, ReactiveFormsModule, ChatComponent]
})
export class TicketComponent implements OnInit {

  constructor(private tktSrv: TicketService, private fb: FormBuilder, private accSrv: AccountService, private http: HttpClient) { }

  stateAndPriorityForm!: FormGroup;

  invalid: boolean = true;

  get getTkt() {
    return this.tktSrv;
  }

  get getAcc() {
    return this.accSrv;
  }

  priorities: string[] = [Priorities.Normal,
  Priorities.Important,
  Priorities.VeryImportant,
  Priorities.Urgent];

  prioritiesArray: string[] = [];

  states: string[] = [States.Open,
  States.UnderProcessing,
  States.Suspended,
  States.Canceled,
  States.Resolved,
  States.Closed];

  statesArray: string[] = [];

  ngOnInit(): void {
    this.prioritiesArray = [];
    this.priorities.forEach(priority => {
      if (priority != this.tktSrv.ticketObject.priority) {
        this.prioritiesArray.push(priority);
      }
    });
    this.statesArray = [];
    this.states.forEach(state => {
      if (state != this.tktSrv.ticketObject.state) {
        this.statesArray.push(state);
      }
    });
    this.stateAndPriorityForm = this.fb.group({
      state: [''],
      priority: ['']
    });
  }

  change(): void {
    this.invalid = false;
  }

  submit(): void {
    let ticket: Ticket = this.tktSrv.ticketObject;
    ticket.state = this.stateAndPriorityForm.value.state != '' ? this.stateAndPriorityForm.value.state : ticket.state;
    ticket.priority = this.stateAndPriorityForm.value.priority != '' ? this.stateAndPriorityForm.value.priority : ticket.priority;
    ticket.version = ticket.version + 1;
    this.http.post('http://localhost:8080/tickets/update', ticket).subscribe(
      then => {
        alert('Modifiche effettuate sul ticket');
        this.invalid = true;
      }
    );
  }
}
