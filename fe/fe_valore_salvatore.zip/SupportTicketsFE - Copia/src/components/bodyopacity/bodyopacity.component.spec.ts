import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BodyOpacityComponent } from './bodyopacity.component';

describe('BodyOpacityComponent', () => {
  let component: BodyOpacityComponent;
  let fixture: ComponentFixture<BodyOpacityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BodyOpacityComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BodyOpacityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
