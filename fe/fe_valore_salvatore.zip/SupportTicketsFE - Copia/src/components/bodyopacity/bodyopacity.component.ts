import { Component } from '@angular/core';
import { SideBarLeftOpeningService } from '../../services/sidebarleftopening.service';
import { NgStyle } from '@angular/common';

@Component({
  selector: 'bodyopacity',
  standalone: true,
  imports: [NgStyle],
  templateUrl: './bodyopacity.component.html',
  styleUrl: './bodyopacity.component.css'
})
export class BodyOpacityComponent {
 constructor(private sdbOp: SideBarLeftOpeningService) { }

 get getSdbOp() {
  return this.sdbOp;
 }

 toggleSideBarLeft() {
  if(this.getSdbOp.isOpened){
    this.getSdbOp.toggleSideBarLeft();
  }
 }
}
