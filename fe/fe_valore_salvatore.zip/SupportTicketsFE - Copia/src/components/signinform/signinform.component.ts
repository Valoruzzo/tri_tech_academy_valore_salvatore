import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Strings } from '../../interfaces/strings.interface';
import { Customer, Operator } from '../../interfaces/artificialtypes.interface';
import { CommonModule } from '@angular/common';
import { AccountService } from '../../services/account.service';
import { LoadingService } from '../../services/loading.service';

@Component({
  selector: 'signinform',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './signinform.component.html',
  styleUrl: './signinform.component.css'
})
export class SignInFormComponent implements OnInit {

  constructor(private fb: FormBuilder, private http: HttpClient, private accSrv: AccountService, private ldgSrv: LoadingService) { }

  signInForm!: FormGroup;

  emailError: boolean = false;

  get getStrings() {
    return Strings;
  }

  get getAcc() {
    return this.accSrv;
  }

  ngOnInit(): void {
    this.signInForm = this.fb.group({
      firstName: [this.accSrv.fillRegistration[0], [Validators.required, Validators.minLength(3)]],
      lastName: [this.accSrv.fillRegistration[1], [Validators.required, Validators.minLength(3)]],
      birthDate: [this.accSrv.fillRegistration[2], [Validators.required]],
      phoneNumber: [this.accSrv.fillRegistration[3], [Validators.required, Validators.min(100000)]],
      address: [this.accSrv.fillRegistration[4]],
      type: [this.accSrv.fillRegistration[5], [Validators.required]],
      email: [this.accSrv.fillRegistration[6], [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{6,12}$")]]
    });
  }

  submit(): void{
    let email = this.signInForm.value.email;
    this.accSrv.checkCustomerEmail(email)
    .subscribe(customer => {
      if(customer == null){
        this.accSrv.checkOperatorEmail(email)
        .subscribe(operator => {
          if(operator == null){
            this.addAccount();
            this.emailError = false;
          } else {
            this.emailError = true;
          }
        })
      } else {
        this.emailError = true;
      }
    });
  }

  addAccount(): void{
    this.ldgSrv.loading = true;
    if(this.signInForm.value.type == this.getStrings.customerTypeValue){
      let customer: Customer = {
        id: 0,
        firstName: this.signInForm.value.firstName,
        lastName: this.signInForm.value.lastName,
        email: this.signInForm.value.email,
        password: this.signInForm.value.password,
        birthDate: this.signInForm.value.birthDate,
        phoneNumber: `${this.signInForm.value.phoneNumber}`,
        address: this.signInForm.value.address != '' ? this.signInForm.value.address : "Indirizzo sconosciuto"
      }
      this.accSrv.addAccount(customer, "customer").subscribe(then => {
        this.accSrv.saveAccount(customer.email, "customer");
      });
    } else if(this.signInForm.value.type == this.getStrings.operatorTypeValue){
      let operator: Operator = {
        id: 0,
        firstName: this.signInForm.value.firstName,
        lastName: this.signInForm.value.lastName,
        email: this.signInForm.value.email,
        password: this.signInForm.value.password,
        birthDate: this.signInForm.value.birthDate,
        phoneNumber: `${this.signInForm.value.phoneNumber}`,
        address: this.signInForm.value.address != '' ? this.signInForm.value.address : "Indirizzo sconosciuto",
        authorizationLevel: this.getStrings.operatorTypeValue
      }
      this.accSrv.addAccount(operator, "operator").subscribe(then => {
        this.accSrv.saveAccount(operator.email, "operator");
      });
    }
  }
}
