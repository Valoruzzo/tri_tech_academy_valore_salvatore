import { Component } from '@angular/core';

@Component({
  selector: 'app-logoutconfirm',
  standalone: true,
  imports: [],
  templateUrl: './logoutconfirm.component.html',
  styleUrl: './logoutconfirm.component.css'
})
export class LogoutconfirmComponent {

}
