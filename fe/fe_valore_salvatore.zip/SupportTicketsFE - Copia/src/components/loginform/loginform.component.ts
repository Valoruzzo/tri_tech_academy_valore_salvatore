import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Strings } from '../../interfaces/strings.interface';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { AccountService } from '../../services/account.service';
import { LoadingService } from '../../services/loading.service';

@Component({
  selector: 'loginform',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './loginform.component.html',
  styleUrl: './loginform.component.css'
})
export class LogInFormComponent implements OnInit {

  constructor(private fb: FormBuilder, private http: HttpClient, private accSrv: AccountService, private ldgSrv: LoadingService) { }

  logInForm!: FormGroup;

  emailError: boolean = false;
  passwordError: boolean = false;

  get getStrings() {
    return Strings;
  }

  get getAcc() {
    return this.accSrv;
  }

  ngOnInit(): void {
    this.logInForm = this.fb.group({
      email: [this.accSrv.fillAccess[0], [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{6,12}$")]]
    });
  }

  submit(): void {
    let email = this.logInForm.value.email;
    let password = this.logInForm.value.password;
    this.accSrv.checkCustomerEmail(email).subscribe(customer => {
      if (customer != null) {
        this.checkPassword(customer, password, "customer");
        this.emailError = false;
      } else {
        this.accSrv.checkOperatorEmail(email).subscribe(operator => {
          if (operator != null) {
            this.checkPassword(operator, password, "operator");
            this.emailError = false;
          } else {
            this.checkPassword(operator, '', '');
          } 
        });
      }
    });
  }

  checkPassword(account: any, password: string, type: string): void{
    if(account == null){
      this.emailError = true;
      this.passwordError = false;
    } else {
      if(account.password != password){
        this.passwordError = true;
      } else {
        this.ldgSrv.loading = true;
        this.getAcc.saveAccount(account.email, type);
        this.emailError = false;
        this.passwordError = false;
      }
    }
  }
}
