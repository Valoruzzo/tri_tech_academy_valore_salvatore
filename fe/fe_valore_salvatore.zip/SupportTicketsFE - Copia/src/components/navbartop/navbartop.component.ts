import { Component } from '@angular/core';
import { SideBarLeftOpeningService } from '../../services/sidebarleftopening.service';
import { Router } from '@angular/router';
import { SideBarLeftComponent } from '../sidebarleft/sidebarleft.component';
import { BodyOpacityComponent } from '../bodyopacity/bodyopacity.component';

@Component({
  selector: 'navbartop',
  standalone: true,
  imports: [SideBarLeftComponent, BodyOpacityComponent],
  templateUrl: './navbartop.component.html',
  styleUrl: './navbartop.component.css'
})
export class NavBarTopComponent {
  constructor(private sdbOp: SideBarLeftOpeningService, private router: Router) { }

  get getSdbOp(){
    return this.sdbOp;
  }

  navigateToPage(page: string): void{
    this.router.navigate(["/" + page]);
  }
}