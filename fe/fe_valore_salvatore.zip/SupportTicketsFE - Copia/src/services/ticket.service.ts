import { Injectable } from '@angular/core';
import { Ticket } from '../interfaces/artificialtypes.interface';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Priorities, States } from '../interfaces/enums.interface';
import { Strings } from '../interfaces/strings.interface';
import { LoadingService } from './loading.service';

@Injectable({
  providedIn: 'root'
})
export class TicketService {

  constructor(private http: HttpClient, private ldgSrv: LoadingService) { }

  singleTicket: boolean = false;
  ticketId: number = -1;
  ticket: any = [];
  ticketObject!: Ticket;

  createTicket: boolean = true;

  ticketFields: any[] = [];

  get getStrings() {
    return Strings;
  }

  get getStates() {
    return States;
  }

  get getPriorities() {
    return Priorities;
  }

  getTicket(id: number) {
    this.ticketId = id;
    this.ldgSrv.loading = true;
    this.http.get<Ticket>('http://localhost:8080/tickets/getById' + '?id=' + id)
      .subscribe(ticket => {
        this.ticketObject = ticket;
        this.ticket = [];
        this.ticket.push(ticket.object);
        this.ticket.push(ticket.description);
        this.ticket.push(ticket.furtherInformations);
        this.ticket.push(ticket.documentation);
        this.ticket.push(ticket.state);
        this.ticket.push(ticket.priority);
        this.ticket.push(ticket.creationDate);
        this.ticket.push(ticket.customer.firstName);
        this.ticket.push(ticket.customer.lastName);
        this.ticket.push(ticket.customer.email);
        this.ldgSrv.loading = false;
      });
  }

  getAllTickets() {
    this.singleTicket = false;
    this.ticket = [];
  }

  addTicket(ticket: Ticket): Observable<any> {
    return this.http.post('http://localhost:8080/tickets/add', ticket);
  }

  download!: HTMLAnchorElement;

  downloadDocumentation() {
    const base64Data = 'data:application/pdf;base64,' + this.ticket[3];
    const blob = this.base64toBlob(base64Data);
    const blobUrl = window.URL.createObjectURL(blob);
    this.download = document.createElement('a');
    this.download.href = blobUrl;
    this.download.download = 'documentation.pdf';
    this.download.click();
    window.URL.revokeObjectURL(blobUrl);
  }

  base64toBlob(base64Data: string) {
    const byteString = atob(base64Data.split(',')[1]);
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([ab], { type: 'application/pdf' });
  }
}
