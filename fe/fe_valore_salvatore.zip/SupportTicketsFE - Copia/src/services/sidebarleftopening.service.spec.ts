import { TestBed } from '@angular/core/testing';

import { SideBarLeftOpeningService } from './sidebarleftopening.service';

describe('SideBarLeftOpeningService', () => {
  let service: SideBarLeftOpeningService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SideBarLeftOpeningService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
