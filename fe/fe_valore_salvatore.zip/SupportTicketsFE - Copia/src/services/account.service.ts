import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Customer, Operator } from '../interfaces/artificialtypes.interface';
import { Observable } from 'rxjs';
import { LoadingService } from './loading.service';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private http: HttpClient, private ldgSrv: LoadingService) { }

  accountIsLogged = false;
  registration = false;
  accountId = 0;
  accountEmail = '';
  accountType = '';
  account: any[] = [];
  fillRegistration: any[] = [];
  fillAccess: any[] = [];

  saveAccount(email: string, type: string) {
    this.accountIsLogged = true;
    this.accountEmail = email;
    this.accountType = type;
    if(this.accountType == "customer"){
      this.checkCustomerEmail(this.accountEmail).subscribe(customer => {
        this.account = [];
        this.accountId = customer.id;
        this.account.push(customer.firstName);
        this.account.push(customer.lastName);
        this.account.push(customer.email);
        this.account.push(customer.birthDate);
        this.account.push(customer.phoneNumber);
        this.account.push(customer.address);
        this.ldgSrv.loading = false;
    });
    } else if(this.accountType == "operator"){
      this.checkOperatorEmail(this.accountEmail).subscribe(operator => {
        this.account = [];
        this.accountId = operator.id;
        this.account.push(operator.firstName);
        this.account.push(operator.lastName);
        this.account.push(operator.email);
        this.account.push(operator.birthDate);
        this.account.push(operator.phoneNumber);
        this.account.push(operator.address);
        this.account.push(operator.authorizationLevel);
        this.ldgSrv.loading = false;
      });
    }
  }

  checkCustomerEmail(email: string): Observable<Customer> {
    return this.http.get<Customer>('http://localhost:8080/customers/getByEmail' + '?email=' + email);
  }

  checkOperatorEmail(email: string): Observable<Operator> {
    return this.http.get<Operator>('http://localhost:8080/operators/getByEmail' + '?email=' + email);
  }

  addAccount(account: any, type: string): Observable<any> {
    return this.http.post('http://localhost:8080/' + type + 's/add', account);
  }

  logIn() {
    this.registration = false;
  }

  signIn() {
    this.registration = true;
  }
}
