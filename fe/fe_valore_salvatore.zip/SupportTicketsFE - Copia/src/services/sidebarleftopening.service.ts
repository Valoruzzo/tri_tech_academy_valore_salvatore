import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SideBarLeftOpeningService {
  constructor() { }

  isOpened: boolean = false;
  isFullClosed: boolean = true;
  isFullOpened: boolean = false;

  toggleSideBarLeft(): void{
    this.isOpened = !this.isOpened;
    if(this.isOpened){
      this.isFullClosed = !this.isFullClosed;
      setTimeout(() => {
        this.isFullOpened = !this.isFullOpened;
      }, 1);
    } else {
      this.isFullOpened = !this.isFullOpened;
      setTimeout(() => {
        this.isFullClosed = !this.isFullClosed;
      }, 250);
    }
  }
}
